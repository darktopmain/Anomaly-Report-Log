﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;
using WpfMessageBox = System.Windows.MessageBox;

namespace Winsock
{
    public partial class Esclavo : Window
    {
        private NotifyIcon notifyIcon;

        private bool ventanaInicializada = false;

        public Esclavo()
        {
            InitializeComponent();

            // Inicializa NotifyIcon
            notifyIcon = new NotifyIcon();

            try
            {
                // Ruta absoluta al icono
                string iconPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "win.ico");
                notifyIcon.Icon = new Icon(iconPath);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Error al cargar win.ico: " + ex.Message);
                notifyIcon.Icon = SystemIcons.Application; // Ícono por defecto
            }

            notifyIcon.Visible = true;
            notifyIcon.Text = "Mi aplicación WPF";
            notifyIcon.DoubleClick += NotifyIcon_DoubleClick;

            // Menú contextual
            notifyIcon.ContextMenuStrip = new ContextMenuStrip();
            notifyIcon.ContextMenuStrip.Items.Add("Restaurar", null, (s, e) =>
            {
                System.Windows.Application.Current.Dispatcher.Invoke(() =>
                {
                    var mainWindow = System.Windows.Application.Current.MainWindow;
                    if (mainWindow != null)
                    {
                        mainWindow.Show();
                        mainWindow.WindowState = WindowState.Normal;
                        mainWindow.Activate();
                    }
                });
            });

            notifyIcon.ContextMenuStrip.Items.Add("Minimizar", null, (s, e) =>
            {
                System.Windows.Application.Current.Dispatcher.Invoke(() =>
                {
                    var mainWindow = System.Windows.Application.Current.MainWindow;
                    if (mainWindow != null)
                    {
                        mainWindow.WindowState = WindowState.Minimized;
                    }
                });
            });

            notifyIcon.ContextMenuStrip.Items.Add("Salir", null, (s, e) =>
            {
                System.Windows.Application.Current.Dispatcher.Invoke(() =>
                {
                    var mainWindow = System.Windows.Application.Current.MainWindow;
                    if (mainWindow != null)
                        mainWindow.Close(); // Se ejecutará Window_Closing
                });
            });

            // Mostrar la ventana al iniciar
            this.Show();
            this.WindowState = WindowState.Normal;

            // Marcar ventana como lista
            ventanaInicializada = true;
        }

        private void NotifyIcon_DoubleClick(object sender, EventArgs e)
        {
            this.Show();
            this.WindowState = WindowState.Normal;
            this.Activate();
        }

        protected override void OnStateChanged(EventArgs e)
        {
            base.OnStateChanged(e);

            if (ventanaInicializada && WindowState == WindowState.Minimized)
                this.Hide(); // Oculta solo si ya fue mostrada
        }

        protected override void OnClosed(EventArgs e)
        {
            notifyIcon.Dispose();
            base.OnClosed(e); // Ya se está cerrando, no llames this.Close()
        }

        private void BtnEnviar_Click(object sender, RoutedEventArgs e)
        {
            string ipServidor = txtIP.Text.Trim();
            string mensaje = txtMensaje.Text.Trim();

            if (string.IsNullOrWhiteSpace(ipServidor) || string.IsNullOrWhiteSpace(mensaje))
            {
                WpfMessageBox.Show("IP y mensaje no pueden estar vacíos.");
                return;
            }

            try
            {
                GuardarEnBaseDeDatos(mensaje);

                TcpClient client = new TcpClient(ipServidor, 4000);
                NetworkStream stream = client.GetStream();

                byte[] data = Encoding.ASCII.GetBytes("NUEVO");
                stream.Write(data, 0, data.Length);

                stream.Close();
                client.Close();

                WpfMessageBox.Show("Mensaje enviado correctamente.");
                txtMensaje.Clear();
            }
            catch (Exception ex)
            {
                WpfMessageBox.Show("Error: " + ex.Message);
            }
        }

        private void GuardarEnBaseDeDatos(string mensaje)
        {
            string connectionString = "Data Source=PRYDSKMDPRPRO04;Initial Catalog=Molding;User ID=Molding;Password=!Mdlevel*;TrustServerCertificate=True";
            string query = "INSERT INTO Mensajes (Emisor, Texto) VALUES (@emisor, @texto)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@emisor", Combo.Text);
                cmd.Parameters.AddWithValue("@texto", mensaje);
                cmd.ExecuteNonQuery();
            }
        }

        private void Combo_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Combo.IsEnabled = false;
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            string contraseñaCorrecta = "smt123";

            PasswordForm passwordWindow = new PasswordForm();
            bool? resultado = passwordWindow.ShowDialog();

            if (resultado != true || passwordWindow.Password != contraseñaCorrecta)
            {
                e.Cancel = true;
                WpfMessageBox.Show("Contraseña incorrecta. No se cerrará la aplicación.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void cerrar()
        {
            string contraseñaCorrecta = "smt123";

            PasswordForm passwordWindow = new PasswordForm();
            bool? resultado = passwordWindow.ShowDialog();

            if (resultado == true && passwordWindow.Password == contraseñaCorrecta)
            {
                this.Close();
            }
            else
            {
                WpfMessageBox.Show("Contraseña incorrecta. No se cerrará la aplicación.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void txtIP_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            txtIP.Visibility = Visibility.Hidden;
        }


    }
}
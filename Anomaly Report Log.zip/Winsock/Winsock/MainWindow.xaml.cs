﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using Microsoft.Data.SqlClient;

namespace Winsock
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private TcpListener servidor;
        private Thread hiloServidor;

        public MainWindow()
        {
            InitializeComponent();


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            hiloServidor = new Thread(IniciarServidor);
            hiloServidor.IsBackground = true;
            hiloServidor.Start();
            txtMensajes.AppendText("Servidor iniciado en el puerto 4000\n");
        }

        private void IniciarServidor()
        {
            try
            {
                servidor = new TcpListener(IPAddress.Any, 4000);
                servidor.Start();

                while (true)
                {
                    TcpClient cliente = servidor.AcceptTcpClient();
                    NetworkStream stream = cliente.GetStream();

                    byte[] buffer = new byte[256];
                    int leidos = stream.Read(buffer, 0, buffer.Length);
                    string mensaje = Encoding.ASCII.GetString(buffer, 0, leidos);

                    if (mensaje == "NUEVO")
                    {
                        string mensajesDB = LeerMensajesDesdeBD();
                        Dispatcher.Invoke(() =>
                        {
                            txtMensajes.AppendText("📥 Señal recibida desde esclavo\n");
                            txtMensajes.AppendText(mensajesDB + "\n");
                        });
                    }
                    else
                    {
                        Dispatcher.Invoke(() =>
                        {
                            txtMensajes.AppendText($"📨 Mensaje recibido: {mensaje}\n");
                        });
                    }

                    stream.Close();
                    cliente.Close();
                }
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() =>
                {
                    txtMensajes.AppendText($"❌ Error: {ex.Message}\n");
                });
            }
        }

        private string LeerMensajesDesdeBD()
        {
            StringBuilder sb = new StringBuilder();

            try
            {
                string connectionString = "Data Source=PRYDSKMDPRPRO04;Initial Catalog=Molding;User ID=Molding;Password=!Mdlevel*;TrustServerCertificate=True";
                string query = "SELECT TOP 1 * FROM Mensajes ORDER BY FechaHora DESC";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        DateTime fecha = (DateTime)reader["FechaHora"];
                        string emisor = reader["Emisor"].ToString();
                        string texto = reader["Texto"].ToString();

                        sb.AppendLine($"{fecha:HH:mm:ss} - {emisor}: {texto}");
                    }
                }
            }
            catch (Exception ex)
            {
                sb.AppendLine("❌ Error al leer la base de datos: " + ex.Message);
            }

            return sb.ToString();
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            Environment.Exit(0); // Cierra el hilo del servidor correctamente
        }
    }
}
